fixepg = False
current_playlist = []
name = ""
old_name = ""
firstrun = 0
current_selection = 0
finished = False
currentref = ""
